# DUMBYBELLY — The Aesthetic Archive

A static, responsive website about Zyzz, David Laid, and Jeff Seid. Built with plain HTML, CSS, and JavaScript so it can be deployed directly to Netlify without a build step.

## Preview locally
Open `index.html` in a modern browser, or run a simple local server from this folder:
- Python: `python -m http.server 8000`
- Then visit `http://localhost:8000`

## Deploy to Netlify
1. Download and unzip `dumbybelly-netlify.zip`.
2. Go to https://app.netlify.com/drop
3. Drag the unzipped `dumbybelly-site` folder (the folder containing `index.html`) onto the drop area.
4. Netlify will publish the site and give you a public URL. You can change the site name/domain from your Netlify dashboard.

No build command or publish directory is needed for this static version.

## Included
- Cinematic DUMBYBELLY homepage
- Real-time Three.js low-poly 3D character models built from procedural meshes, inspired by PS2-era graphics
- Three interactive profile overlays
- Physique/career comparison
- TikTok and YouTube links for @dumbybelly
- Responsive mobile layout and reduced-motion support

## Important asset note
The hero uses real-time interactive low-poly 3D models built from procedural meshes. They are stylized original models inspired by PS2-era graphics, not photorealistic scans or exact likenesses. For recognizable likenesses, replace them with licensed/commissioned GLB or glTF models.

## Customize
- Edit biographies and facts in `script.js`.
- Edit layout, colors, and typography in `styles.css`.
- Edit page content and links in `index.html`.
