(() => {
  const canvas = document.getElementById("threeCanvas");
  const stage = document.getElementById("heroStage");
  if (!canvas || !window.THREE) {
    if (stage) stage.insertAdjacentHTML("beforeend", '<p style="position:absolute;inset:40% 10%;text-align:center;color:#aaa">3D scene unavailable in this browser.</p>');
    return;
  }

  const THREE = window.THREE;
  const scene = new THREE.Scene();
  scene.background = new THREE.Color(0x08080e);
  scene.fog = new THREE.FogExp2(0x08080e, 0.035);

  const camera = new THREE.PerspectiveCamera(35, 1, 0.1, 100);
  camera.position.set(0, 3.1, 13.8);
  const renderer = new THREE.WebGLRenderer({canvas, antialias: false, alpha: false, powerPreference: "high-performance"});
  renderer.setPixelRatio(Math.min(window.devicePixelRatio || 1, 1.6));
  renderer.shadowMap.enabled = true;
  renderer.shadowMap.type = THREE.BasicShadowMap;
  renderer.outputColorSpace = THREE.SRGBColorSpace;
  renderer.toneMapping = THREE.ACESFilmicToneMapping;
  renderer.toneMappingExposure = 1.15;

  scene.add(new THREE.HemisphereLight(0x8798c9, 0x1c1425, 2.0));
  const key = new THREE.DirectionalLight(0xffd8c1, 3.0); key.position.set(-4, 8, 7); scene.add(key);
  const rimPurple = new THREE.PointLight(0x8a38ff, 28, 15); rimPurple.position.set(-5, 3, -1); scene.add(rimPurple);
  const rimBlue = new THREE.PointLight(0x087dff, 24, 15); rimBlue.position.set(4, 3, -2); scene.add(rimBlue);
  const fill = new THREE.PointLight(0xd8e4ff, 10, 18); fill.position.set(0, 5, 5); scene.add(fill);

  const floorMat = new THREE.MeshStandardMaterial({color:0x12121a, roughness:.72, metalness:.45});
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(100,100), floorMat);
  floor.rotation.x = -Math.PI/2; floor.position.y = -0.03; floor.receiveShadow = true; scene.add(floor);
  const grid = new THREE.GridHelper(60, 55, 0x37304e, 0x242231); grid.position.y = 0.01; grid.material.transparent = true; grid.material.opacity = .4; scene.add(grid);

  // Low-poly mesh helpers: the deliberately faceted shapes evoke a PS2-era character model.
  const mat = (color, roughness=.82, metalness=.05) => new THREE.MeshStandardMaterial({color, roughness, metalness, flatShading:true});
  const sphereGeo = new THREE.IcosahedronGeometry(1, 1);
  function part(group, geometry, material, pos, scale, rot) {
    const mesh = new THREE.Mesh(geometry, material);
    mesh.position.set(...pos); mesh.scale.set(...scale);
    if (rot) mesh.rotation.set(...rot);
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh); return mesh;
  }
  function capsule(group, material, a, b, radiusA, radiusB, segments=7) {
    const va = new THREE.Vector3(...a), vb = new THREE.Vector3(...b);
    const dir = new THREE.Vector3().subVectors(vb, va);
    const mesh = new THREE.Mesh(new THREE.CylinderGeometry(radiusB, radiusA, dir.length(), segments, 1, false), material);
    mesh.position.copy(va).add(vb).multiplyScalar(.5);
    mesh.quaternion.setFromUnitVectors(new THREE.Vector3(0,1,0), dir.normalize());
    mesh.castShadow = true; mesh.receiveShadow = true; group.add(mesh);
    part(group, new THREE.IcosahedronGeometry(radiusA,0), material, a, [1,1,1]);
    part(group, new THREE.IcosahedronGeometry(radiusB,0), material, b, [1,1,1]);
    return mesh;
  }
  function createLegend(config) {
    const g = new THREE.Group();
    const skin = mat(config.skin, .9);
    const skinLight = mat(config.skinLight, .82);
    const hair = mat(config.hair, 1);
    const shorts = mat(config.shorts, .95);
    const dark = mat(config.shoes, .9);
    const accent = mat(config.accent, .45, .18);
    // Feet and legs
    part(g, new THREE.BoxGeometry(.44,.22,.72), dark, [-.25,.12,.12], [1,1,1], [0,.08,0]);
    part(g, new THREE.BoxGeometry(.44,.22,.72), dark, [.25,.12,.12], [1,1,1], [0,-.08,0]);
    capsule(g, skin, [-.25,.25,0], [-.27,1.0,0], .16,.19,7);
    capsule(g, skinLight, [-.27,1.0,0], [-.23,1.82,0], .18,.23,7);
    capsule(g, skin, [.25,.25,0], [.27,1.0,0], .16,.19,7);
    capsule(g, skinLight, [.27,1.0,0], [.23,1.82,0], .18,.23,7);
    part(g, new THREE.BoxGeometry(.76,.52,.46), shorts, [0,2.0,0], [1,1,1], [0,0,0]);
    // Torso / V taper
    part(g, new THREE.CylinderGeometry(.31,.52,.86,8,1), skin, [0,2.64,0], [1,1,1], [0,0,0]);
    part(g, new THREE.IcosahedronGeometry(.62,1), skinLight, [0,3.12,0], [1.0,.42,.36]);
    part(g, new THREE.IcosahedronGeometry(.25,1), skin, [-.25,3.04,.31], [1,.9,.55]);
    part(g, new THREE.IcosahedronGeometry(.25,1), skin, [.25,3.04,.31], [1,.9,.55]);
    // Abdominal plates, angular rather than realistic
    for (let row=0; row<3; row++) for (let col=0; col<2; col++) {
      part(g, new THREE.BoxGeometry(.18,.17,.045), skinLight, [col===0?-.115:.115,2.78-row*.19,.385], [1,1,1], [0,0,(col===0?-.04:.04)]);
    }
    // Shoulders, arms, forearms, hands
    for (const side of [-1,1]) {
      part(g, new THREE.IcosahedronGeometry(.29,1), skinLight, [side*.57,3.14,0], [1,.9,1]);
      capsule(g, skin, [side*.62,3.05,0], [side*.76,2.56,.02], .19,.14,7);
      capsule(g, skinLight, [side*.76,2.56,.02], [side*.79,2.02,.08], .14,.105,7);
      part(g, sphereGeo, skin, [side*.79,1.91,.08], [.12,.16,.12]);
    }
    // Neck, head, ears, nose, brows
    capsule(g, skin, [0,3.32,0], [0,3.57,0], .14,.13,7);
    part(g, new THREE.IcosahedronGeometry(.29,1), skinLight, [0,3.82,.015], [.82,1.1,.8]);
    part(g, new THREE.IcosahedronGeometry(.07,0), skin, [-.26,3.82,0], [1,1.3,.8]);
    part(g, new THREE.IcosahedronGeometry(.07,0), skin, [.26,3.82,0], [1,1.3,.8]);
    part(g, new THREE.ConeGeometry(.055,.15,5), skin, [0,3.79,.25], [1,1,1], [Math.PI/2,0,0]);
    part(g, new THREE.IcosahedronGeometry(.30,1), hair, [0,4.03,-.035], [1.04,.55,.9]);
    if (config.spikes) {
      for (let i=0;i<7;i++) {
        const spike = new THREE.Mesh(new THREE.ConeGeometry(.075,.28,4), hair);
        spike.position.set((i-3)*.07,4.28+Math.abs(i-3)*-.015,-.015); spike.rotation.z=(i-3)*-.17; g.add(spike);
      }
    } else {
      part(g, new THREE.IcosahedronGeometry(.20,0), hair, [-.11,4.15,-.03], [1.2,.35,.95], [0,0,.1]);
    }
    // Simple eyes, eyebrows, and a dark mouth for a stylized low-poly face
    const eyeMat = new THREE.MeshBasicMaterial({color:0x17151a});
    part(g, new THREE.BoxGeometry(.075,.025,.025), eyeMat, [-.105,3.87,.252], [1,1,1]);
    part(g, new THREE.BoxGeometry(.075,.025,.025), eyeMat, [.105,3.87,.252], [1,1,1]);
    part(g, new THREE.BoxGeometry(.13,.018,.025), mat(0x35241f), [0,3.68,.255], [1,1,1]);
    // Tiny necklace
    const chain = new THREE.Mesh(new THREE.TorusGeometry(.19,.018,4,12,Math.PI), accent);
    chain.position.set(0,3.27,.18); chain.rotation.x=Math.PI; g.add(chain);
    // Add subtle silhouette shoulder-width adjustments by legend.
    g.scale.set(config.scaleX || 1, config.scaleY || 1, 1);
    g.position.x = config.x;
    g.userData.baseY = 0;
    g.userData.spin = config.spin;
    scene.add(g);
    return g;
  }
  const legends = [
    createLegend({x:-3.45, skin:0x8b5f4d, skinLight:0xb98468, hair:0x17151a, shorts:0x10121a, shoes:0x191922, accent:0xa56cff, spikes:true, scaleX:1.02, scaleY:.97, spin:-.17}),
    createLegend({x:0, skin:0xa27f6d, skinLight:0xd0aa91, hair:0x6e5947, shorts:0x11141b, shoes:0x1b1c24, accent:0x51b9ff, scaleX:.94, scaleY:1.02, spin:.08}),
    createLegend({x:3.45, skin:0xa47760, skinLight:0xcba184, hair:0x76563b, shorts:0x15151b, shoes:0x1b1b22, accent:0xd2d9e8, scaleX:1.05, scaleY:1, spin:.18})
  ];

  // Ruined columns and floating polygonal scenery
  const stone = mat(0x292634,.95,.15);
  for (const x of [-6.2,6.2]) {
    const column = new THREE.Mesh(new THREE.CylinderGeometry(.35,.52,5,5,1), stone);
    column.position.set(x,2.45,-1.5); column.rotation.z=x<0?.025:-.025; scene.add(column);
    const cap = new THREE.Mesh(new THREE.BoxGeometry(1.1,.25,1.1), stone); cap.position.set(x,5,-1.5); scene.add(cap);
  }
  for (let i=0;i<18;i++) {
    const rock = new THREE.Mesh(new THREE.IcosahedronGeometry(.15+Math.random()*.35,0), mat(i%2?0x292337:0x18263a,.9));
    rock.position.set((Math.random()-.5)*15,Math.random()*3-1,(Math.random()-.5)*9-2);
    rock.rotation.set(Math.random()*3,Math.random()*3,Math.random()*3); scene.add(rock);
  }
  const moon = new THREE.Mesh(new THREE.IcosahedronGeometry(1.2,1), new THREE.MeshBasicMaterial({color:0x23213a, wireframe:true, transparent:true, opacity:.45}));
  moon.position.set(0,5.7,-5); scene.add(moon);

  let pointerDown=false, lastX=0, drag=0, zoom=0;
  canvas.addEventListener("pointerdown", e=>{pointerDown=true;lastX=e.clientX;canvas.setPointerCapture?.(e.pointerId);});
  canvas.addEventListener("pointerup", ()=>pointerDown=false);
  canvas.addEventListener("pointercancel", ()=>pointerDown=false);
  canvas.addEventListener("pointermove", e=>{if(pointerDown){drag+=(e.clientX-lastX)*.008;lastX=e.clientX;}});
  canvas.addEventListener("wheel", e=>{zoom=Math.max(-2.5,Math.min(3,zoom+e.deltaY*.003));},{passive:true});
  let w=0,h=0;
  function resize(){
    const rect=stage.getBoundingClientRect(); w=Math.max(1,rect.width);h=Math.max(1,rect.height);
    renderer.setSize(w,h,false);camera.aspect=w/h;camera.updateProjectionMatrix();
    const mobile=window.innerWidth<640; camera.position.z=mobile?17.5:13.8;
  }
  window.addEventListener("resize",resize); resize();
  const clock=new THREE.Clock();
  function animate(){
    requestAnimationFrame(animate);
    const t=clock.getElapsedTime();
    camera.position.z=(window.innerWidth<640?17.5:13.8)+zoom;
    camera.lookAt(0,2.1,0);
    legends.forEach((g,i)=>{
      g.rotation.y = g.userData.spin + Math.sin(t*.42+i)*.055 + drag;
      g.position.y = Math.sin(t*1.1+i*1.5)*.035;
    });
    moon.rotation.y=t*.035;
    renderer.render(scene,camera);
  }
  animate();
})();