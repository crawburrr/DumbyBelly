const profiles = {
  zyzz: {
    name: "ZYZZ", kicker: "SUBJECT FILE / 001", tag: "The Aesthetic Icon",
    bio: "Aziz Shavershian, known online as Zyzz, became one of the defining figures of early internet fitness culture. His transformation, confident persona, and memorable catchphrase inspired a generation of gym-goers. His influence continues through memes, edits, and the enduring aesthetic ideal.",
    facts: [
      ["AZIZ SHAVERSHIAN", "Born March 24, 1989 · Died August 5, 2011"],
      ["KNOWN FOR", "Aesthetic bodybuilding and early online fitness culture"],
      ["SIGNATURE LINE", "“We're all gonna make it, brah.”"],
      ["THE ERA", "Late 2000s to 2011 — a defining era of internet fitness"]
    ]
  },
  laid: {
    name: "DAVID LAID", kicker: "SUBJECT FILE / 002", tag: "Built Through Consistency",
    bio: "David Laid rose to prominence through transformation videos and fitness content documenting his development from a slim teenager into a widely recognized fitness personality. His online presence helped shape the visual language of modern gym culture, combining training, physique development, and fashion.",
    facts: [
      ["BORN", "January 29, 1998"],
      ["KNOWN FOR", "Fitness YouTube, transformation videos, training, and fashion"],
      ["SIGNATURE LOOK", "Tall frame, lean muscularity, and balanced proportions"],
      ["THE ERA", "2010s to present — modern creator-led fitness culture"]
    ]
  },
  seid: {
    name: "JEFF SEID", kicker: "SUBJECT FILE / 003", tag: "The Classic Physique",
    bio: "Jeff Seid is a fitness model and men's physique competitor known for his polished presentation and classic V-taper silhouette. His competition career and online fitness presence made him a recognizable figure in the physique-focused fitness scene of the 2010s.",
    facts: [
      ["BORN", "June 12, 1994"],
      ["KNOWN FOR", "Men's physique competition and fitness modeling"],
      ["SIGNATURE LOOK", "Broad shoulders, developed upper body, and a pronounced V-taper"],
      ["THE ERA", "2010s to present — the polished men's physique aesthetic"]
    ]
  }
};

const panel = document.getElementById("profilePanel");
const nameEl = document.getElementById("profileName");
const kickerEl = document.getElementById("profileKicker");
const tagEl = document.getElementById("profileTag");
const bioEl = document.getElementById("profileBio");
const factsEl = document.getElementById("profileFacts");

function openProfile(key) {
  const item = profiles[key];
  if (!item) return;
  nameEl.textContent = item.name;
  kickerEl.textContent = item.kicker;
  tagEl.textContent = item.tag;
  bioEl.textContent = item.bio;
  factsEl.replaceChildren();
  item.facts.forEach(([title, text]) => {
    const fact = document.createElement("div");
    fact.className = "fact";
    const strong = document.createElement("strong");
    strong.textContent = title;
    const span = document.createElement("span");
    span.textContent = text;
    fact.append(strong, span);
    factsEl.append(fact);
  });
  panel.classList.add("open");
  panel.setAttribute("aria-hidden", "false");
  document.body.style.overflow = "hidden";
  document.querySelector(".close-profile").focus();
}
function closeProfile() {
  panel.classList.remove("open");
  panel.setAttribute("aria-hidden", "true");
  document.body.style.overflow = "";
}
document.querySelectorAll("[data-open]").forEach(btn => btn.addEventListener("click", () => openProfile(btn.dataset.open)));
document.querySelector(".close-profile").addEventListener("click", closeProfile);
panel.addEventListener("click", event => { if (event.target === panel) closeProfile(); });
document.addEventListener("keydown", event => { if (event.key === "Escape") closeProfile(); });

const menuToggle = document.querySelector(".menu-toggle");
const nav = document.querySelector(".topbar nav");
menuToggle.addEventListener("click", () => {
  const isOpen = nav.classList.toggle("mobile-open");
  menuToggle.setAttribute("aria-expanded", String(isOpen));
  menuToggle.textContent = isOpen ? "×" : "☰";
});
nav.querySelectorAll("a").forEach(link => link.addEventListener("click", () => {
  nav.classList.remove("mobile-open");
  menuToggle.setAttribute("aria-expanded", "false");
  menuToggle.textContent = "☰";
}));

// Gentle pointer parallax for the hero scene.
const stage = document.querySelector(".hero-stage");
if (stage && window.matchMedia("(pointer:fine)").matches && !window.matchMedia("(prefers-reduced-motion: reduce)").matches) {
  document.querySelector(".hero").addEventListener("pointermove", event => {
    const rect = stage.getBoundingClientRect();
    const x = (event.clientX - rect.left) / rect.width - .5;
    const y = (event.clientY - rect.top) / rect.height - .5;
    stage.style.transform = `translate(${x * -10}px, ${y * -6}px)`;
  });
}
